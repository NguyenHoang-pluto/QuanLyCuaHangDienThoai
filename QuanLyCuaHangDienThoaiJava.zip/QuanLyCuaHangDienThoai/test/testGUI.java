
import BUS.KhachHangBUS;
import BUS.SanPhamBUS;
import DTO.KhachHangDTO;
import DTO.SanPhamDTO;
import GUI.BanHangGUI;
import java.util.ArrayList;


public class testGUI {
    public static void main(String[] args) {
//        SanPhamBUS spbus=new SanPhamBUS();
//        ArrayList<SanPhamDTO> listsp=spbus.getAllSanPhamAttribute();
//        for(SanPhamDTO sanpham:listsp){
//            System.out.println(sanpham+"\n");
//        }
//        System.out.println(listsp.size());
//KhachHangBUS KHBUS=new KhachHangBUS();
//ArrayList<KhachHangDTO> list=KHBUS.getAllKhachHang();
//for(KhachHangDTO kh:list){
//    System.out.println(kh+"\n");
//}
    }
}
